package fj.ast;

/**
 * The base class of the various FeatherweightJava expression types.
 */
public abstract class Term {
}
