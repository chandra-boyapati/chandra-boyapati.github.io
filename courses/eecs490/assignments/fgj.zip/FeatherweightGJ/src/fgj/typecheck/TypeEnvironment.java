package fgj.typecheck;

import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import fgj.ast.NonVariableType;
import fgj.ast.Type;
import fgj.ast.TypeParam;
import fgj.ast.TypeVariable;
import fgj.types.ClassTable;
import fgj.types.MethodType;
import fgj.types.TypeSubstitution;
import fgj.util.Pair;

/**
 * The mapping of type variables to their bounds, denoted &Delta; in the
 * FeatherweightGJ paper.
 */
public class TypeEnvironment {

	/**
	 * The class table.
	 */
	public final ClassTable types;

	/**
	 * The underlying type variable mapping.
	 */
	private final Map<String, NonVariableType> env;

	/**
	 * Construct a new type environment using the given class table.
	 * @param types the class table
	 */
	public TypeEnvironment(ClassTable types) {
		this.types = types;
		this.env = Collections.emptyMap();
	}
	
	/**
	 * Construct a new type environment using the given class table.
	 * @param types the class table
	 * @param env the mapping of type variable names to their nonvariable bounds
	 */
	public TypeEnvironment(ClassTable types, Map<String, NonVariableType> env) {
		this.types = types;
		this.env = Collections.unmodifiableMap(env);
	}

	/**
	 * Evaluate the subtype relation on two given types.
	 * @param subType the sub type
	 * @param superType the super type
	 * @return <code>true</code> if <code>subType &lt;: superType</code>;
	 * <code>false</code>otherwise
	 */
	public boolean subtype(Type subType, Type superType) {
 		// TODO implement subtype
 		return true;
	}

	/**
	 * Determine if a particular method override is valid.
	 * @param methodName the method name
	 * @param superType the type containing the method being overridden
	 * @param methodType the type of the subtype's method
	 * @return <code>true</code> if the override is valid; <code>false</code>
	 * otherwise
	 */
	public boolean override(String methodName, NonVariableType superType,
			MethodType methodType) {
		
		// Get the method type in the super type
		MethodType superMethod = types.mtype(methodName, superType);
		if (superMethod == null) return true;
		
		// Construct a substitution
		List<Type> typeArgs = new LinkedList<Type>();
		for (TypeParam typeParam : methodType.typeParams) {
			typeArgs.add(new TypeVariable(typeParam.lineNumber(), typeParam.varName));
		}
		TypeSubstitution subst = new TypeSubstitution(typeArgs, superMethod.typeParams);
		
		// The bounds and argument types must be the same under subst
		for (Pair<TypeParam,TypeParam> p : Pair.zip(methodType.typeParams, superMethod.typeParams)) {
			if (!p.fst.bound.equals(p.snd.bound.applySubstitution(subst))) {
				return false;
			}
		}
		for (Pair<Type,Type> p : Pair.zip(methodType.argTypes, superMethod.argTypes)) {
			if (!p.fst.equals(p.snd.applySubstitution(subst))) {
				return false;
			}
		}
		
		// The return type must be a subtype (doesn't have to be identical)
		if (!subtype(methodType.returnType, superMethod.returnType.applySubstitution(subst))) {
			return false;
		}
				
		// Passed all the tests
		return true;
	}
	
	/**
	 * Determine if a given downcast is valid.
	 * @param castName the name of the class being cast to
	 * @param superName the type we're casting from
	 * @return <code>true</code> if the downcast is valid;
	 * <code>false</code> otherwise
	 */
	public boolean downcast(String castName, String superName) {
		NonVariableType superType = types.superType(castName);
		
		// Transitivity
		if (!superType.className.equals(superName)) {
			return downcast(castName, superType.className) &&
				downcast(superType.className, superName);
		}

		// Build a set of type variables for this class
		Set<String> castTypeVars = new HashSet<String>();
		for (TypeParam typeParam : types.typeParams(castName)) {
			castTypeVars.add(typeParam.varName);
		}
		
		// All of castName's type variables must be used by its superType
		return superType.freeVariables().equals(castTypeVars);
	}

	/**
	 * Determine if a given type variable name is defined in this environment.
	 * @param name the name of the type variable to check
	 * @return <code>true</code> if the type variable is defined
	 */
	public boolean isDefined(String name) {
		return env.containsKey(name);
	}

	/**
	 * Retrieve the bound of this type variable
	 * @param name the name of the type variable
	 * @return its bound
	 */
	public NonVariableType getBound(String name) {
		return env.get(name);
	}
}
