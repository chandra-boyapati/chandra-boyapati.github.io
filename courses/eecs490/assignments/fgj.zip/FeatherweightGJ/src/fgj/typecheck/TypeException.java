package fgj.typecheck;

import fgj.main.FeatherweightGJException;

/**
 * An exception raised during type checking.
 */
public class TypeException extends FeatherweightGJException {

	/**
	 * Construct a type checking exception.
	 * @param message the reason for the exception
	 */
	public TypeException(String message) {
		super("type check error: " + message);
	}
}
