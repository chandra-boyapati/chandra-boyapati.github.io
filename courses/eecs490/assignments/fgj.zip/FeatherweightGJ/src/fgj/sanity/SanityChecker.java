package fgj.sanity;

import java.util.Collection;
import java.util.Map;

import fgj.ast.ClassDecl;

/**
 * Checks the sanity of a FeatherweightGJ program.
 */
public class SanityChecker {

	/**
	 * Maps class names to class declarations.
	 */
	private Map<String, ClassDecl> map;
	
	/**
	 * Construct a sanity checker.
	 * @param map maps class names to class declarations
	 */
	public SanityChecker(Map<String, ClassDecl> map) {
		this.map = map;
	}

	/**
	 * Check the sanity of a collection of possibly insane objects.
	 * @param <T> the type of the objects in the list
	 * @param c the collection of objects to check
	 * @throws InsanityException one of the objects was not sane
	 */
	public <T extends MaybeInsane> void checkList(Collection<T> c) throws InsanityException {
		for (MaybeInsane x : c) {
			x.sanityCheck(this);
		}
	}

	/**
	 * Get the class declaration for a given class.
	 * @param className the class to lookup
	 * @return its declaration, or <code>null</code> if has not been defined
	 */
	public ClassDecl lookupClass(String className) {
		return map.get(className);
	}
}
