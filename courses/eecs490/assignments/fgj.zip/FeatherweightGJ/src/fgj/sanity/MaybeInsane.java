package fgj.sanity;

/**
 * An object that may have a reference to a nonexistent class, or pass the wrong
 * number of arguments in a nonvariable type. 
 */
public interface MaybeInsane {

	/**
	 * Ensure that this object has no weird type naming or numbering issues.
	 * @param sc the sanity checker
	 * @throws InsanityException the object has some reference to a nonexistent class,
	 * or passes the wrong number of arguments in a nonvariable type
	 */
	void sanityCheck(SanityChecker sc) throws InsanityException;
}
