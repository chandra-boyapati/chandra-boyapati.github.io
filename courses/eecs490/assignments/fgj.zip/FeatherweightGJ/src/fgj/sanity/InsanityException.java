package fgj.sanity;

import fgj.ast.Node;
import fgj.main.FeatherweightGJException;

/**
 * An exception raised during class table construction.
 */
public class InsanityException extends FeatherweightGJException {
	
	/**
	 * Construct a class table exception.
	 * @param node the AST node where the failure occurred
	 * @param message the reason for the exception
	 */
	public InsanityException(Node node, String message) {		
		super("error near line " + node.lineNumber() + ": " + message);
	}
}
