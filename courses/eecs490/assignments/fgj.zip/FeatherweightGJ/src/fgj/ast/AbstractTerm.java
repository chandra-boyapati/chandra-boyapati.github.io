package fgj.ast;

import fgj.eval.Evaluator;
import fgj.eval.Value;

/**
 * Superclass of all expression AST nodes.
 */
public abstract class AbstractTerm extends AbstractNode implements Term {

	/**
	 * Construct a term at the given line number.
	 * @param lineNumber the line number for this node
	 */
	protected AbstractTerm(int lineNumber) {
		super(lineNumber);
	}
	
	/**
	 * Throw an error; this method should be overridden to avoid failure.
	 * @param eval the evaluator
	 * @return doesn't return 
	 */
	public Value value(Evaluator eval) {
		throw new Error("something is horribly wrong with the evaluator");
	}
}
