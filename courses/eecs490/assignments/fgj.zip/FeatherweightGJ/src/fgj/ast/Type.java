package fgj.ast;

import java.util.Set;

import fgj.typecheck.TypeEnvironment;
import fgj.typecheck.TypeException;
import fgj.types.Substitutable;

/**
 * The base class of the two kinds of types in FeatherweightGJ:
 * type variables and non-variable types.
 */
public interface Type extends Node, Substitutable<Type> {

	/**
	 * Check that this type meets the well-formedness criteria in a type environment.
	 * @param typeEnv the type environment to look in
	 * @throws TypeException the type is not well formed
	 */
	void checkWellFormed(TypeEnvironment typeEnv) throws TypeException;

	/**
	 * Compute the bound of this type within the given type environment.
	 * @param typeEnv the type environment
	 * @return the nonvariable bound of this type
	 */
	NonVariableType bound(TypeEnvironment typeEnv);
	
	/**
	 * The set of free type variables in this type.
	 * @return the set of free type variables
	 */
	Set<String> freeVariables();
}
