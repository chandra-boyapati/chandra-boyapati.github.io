package fgj.ast;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import fgj.sanity.InsanityException;
import fgj.sanity.SanityChecker;

/**
 * AST node representing a class declaration.
 */
public class ClassDecl extends AbstractNode {

	/**
	 * The name of this class.
	 */
	public final String name;
	
	/**
	 * The type parameters for this parameterized class.
	 */
	public final List<TypeParam> typeParams;
	
	/**
	 * The type extended by this class.
	 */
	public final NonVariableType superType;
	
	/**
	 * The list of {@linkplain Declaration field declarations}
	 * for this class.
	 */
	public final List<Declaration> fields;
	
	/**
	 * The constructor of this class.
	 */
	public final Constructor constructor;
	
	/**
	 * The list of {@link Method} objects for this class.
	 */
	public final List<Method> methods;

	/**
	 * The non-variable type of this class together with its type parameters.
	 */
	public final NonVariableType thisType;
	
	/**
	 * Construct a new class declaration.
	 * @param lineNumber position of this node
	 * @param name the name of the class
	 * @param typeParams the type parameters to the class
	 * @param superType the type extended by this class
	 * @param fields the {@linkplain Declaration field declarations}
	 * of this class
	 * @param constructor the constructor of this class
	 * @param methods the {@link Method} objects of this class
	 */
	public ClassDecl(int lineNumber, String name, List<TypeParam> typeParams, 
			NonVariableType superType, List<Declaration> fields,
			Constructor constructor, List<Method> methods) {
		super(lineNumber);
		this.name = name;
		this.typeParams = Collections.unmodifiableList(typeParams);
		this.superType = superType;
		this.fields = Collections.unmodifiableList(fields);
		this.constructor = constructor;
		this.methods = Collections.unmodifiableList(methods);

		List<Type> typeArgs = new LinkedList<Type>();
		for (TypeParam typeParam : typeParams) {
			typeArgs.add(new TypeVariable(lineNumber, typeParam.varName));
		}
		this.thisType = new NonVariableType(lineNumber, name, typeArgs);
	}

	/**
	 * Sanity check a method declaration.
	 * @param sc the sanity checker
	 * @throws InsanityException one of the type parameters, fields, or methods,
	 * or the super type of the class, was not sane
	 */
	public void sanityCheck(SanityChecker sc) throws InsanityException {
		sc.checkList(typeParams);
		superType.sanityCheck(sc);
		sc.checkList(fields);
		sc.checkList(methods);
	}
}
