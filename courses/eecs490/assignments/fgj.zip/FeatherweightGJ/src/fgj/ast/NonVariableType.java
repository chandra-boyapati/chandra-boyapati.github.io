package fgj.ast;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import fgj.sanity.InsanityException;
import fgj.sanity.SanityChecker;
import fgj.typecheck.TypeEnvironment;
import fgj.typecheck.TypeException;
import fgj.types.Substitution;
import fgj.types.TypeSubstitution;
import fgj.util.Pair;

/**
 * AST node representing a non-variable type.  A non-variable
 * type consists of an actual class name, together with type
 * parameters which may be variable or non-variable.  Casts,
 * <code>new</code> expressions, and type parameter bounds all
 * require non-variable types.
 */
public class NonVariableType extends AbstractNode implements Type {

	/**
	 * The name of the actual class being referenced.
	 */
	public final String className;
	
	/**
	 * The list of type arguments to supply to <code>className</code>.
	 */
	public final List<Type> typeArgs;

	/**
	 * The set of free variable names of this type.
	 */
	private final Set<String> freeVariables;
	
	/**
	 * Construct a new non-variable type.
	 * @param lineNumber position of this node
	 * @param className the name of the actual class
	 * @param typeArgs the list of type arguments 
	 */
	public NonVariableType(int lineNumber, String className, List<Type> typeArgs) {
		super(lineNumber);
		this.className = className;
		this.typeArgs = Collections.unmodifiableList(typeArgs);
		
		Set<String> freeVars = new HashSet<String>();
		for (Type ty : typeArgs) {
			freeVars.addAll(ty.freeVariables());
		}
		this.freeVariables = Collections.unmodifiableSet(freeVars);
	}
	
	/**
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return className + strTypes(typeArgs);
	}

	/**
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object o) {
		if (!(o instanceof NonVariableType)) return false;
		NonVariableType t = (NonVariableType) o;
		if (!t.className.equals(this.className)) return false;
		return t.typeArgs.equals(this.typeArgs);
	}

	/**
	 * Return <code>true</code> if this non-variable type
	 * refers to <code>Object</code>, the root of the
	 * FeatherweightGJ class hierarchy.
	 * @return <code>true</code> if this non-variable type
	 * refers to <code>Object</code>; <code>false</code> otherwise
	 */
	public boolean isObject() {
		return equals(OBJECT);
	}
	
	/**
	 * The non-variable type <code>Object</code>. 
	 */
	private static final NonVariableType OBJECT;
	static {
		List<Type> typeArgs = Collections.emptyList();
		OBJECT = new NonVariableType(0, "Object", typeArgs);		
	}

	/**
	 * Apply a substitution to this nonvariable type.
	 * @param subst the substitution to apply
	 * @return this type, with the substitution applied to the type arguments
	 */
	public NonVariableType applySubstitution(Substitution<?> subst) {
		return new NonVariableType(lineNumber, className, subst.applyToList(typeArgs));
	}

	/**
	 * Ensure that this nonvariable type is well-formed in the given type environment.
	 * @param typeEnv the type environment
	 * @throws TypeException the type is not well-formed
	 */
	public void checkWellFormed(TypeEnvironment typeEnv) throws TypeException {
		
		// Object is well-formed
		if (isObject()) return;
		
		// Type arguments must be well-formed
		for (Type typeArg : typeArgs) {
			typeArg.checkWellFormed(typeEnv);
		}
		
		// Get the type parameters for this class and build a substitution
		List<TypeParam> typeParams = typeEnv.types.typeParams(className);
		TypeSubstitution subst = new TypeSubstitution(typeArgs, typeParams);
		
		// The type arguments must be subtypes of their bounds
		for (Pair<Type,TypeParam> p : Pair.zip(typeArgs, typeParams)) {
			if (!typeEnv.subtype(p.fst, p.snd.bound.applySubstitution(subst))) {
				throw new TypeException("type argument must be subtype of bound");
			}
		}
	}

	/**
	 * Compute our nonvariable bound, which is <code>this</code>.
	 * @param typeEnv the type environment
	 * @return <code>this</code>
	 */
	public NonVariableType bound(TypeEnvironment typeEnv) {
		return this;
	}

	/**
	 * @see fgj.ast.Type#freeVariables()
	 */
	public Set<String> freeVariables() {
		return freeVariables;
	}

	/**
	 * Sanity check this nonvariable type.
	 * @param sc the sanity checker
	 * @throws InsanityException <code>className</code> is not the name
	 * of a class, one of <code>typeArgs</code> is not sane, or the wrong number of
	 * type arguments are being supplied to <code>className</code>
	 */
	public void sanityCheck(SanityChecker sc) throws InsanityException {
		sc.checkList(typeArgs);
		int argCount = typeArgs.size();
		
		if (className.equals("Object")) {
			if (argCount != 0) {
				throw new InsanityException(this, "Object has no type parameters");
			}
		}
		else {
			ClassDecl cd = sc.lookupClass(className);
			if (cd == null) {
				throw new InsanityException(this, "unknown class \"" + className + "\"");
			}
			int correctCount = cd.typeParams.size();
			if (correctCount != argCount) {
				throw new InsanityException(this, "class \"" + className + "\" takes "
						+ correctCount + " type parameters, but was given " + argCount);
			}
		}
	}
}
