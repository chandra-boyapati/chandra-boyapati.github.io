package fgj.ast;

import fgj.eval.EvaluationException;
import fgj.eval.Evaluator;
import fgj.eval.Value;
import fgj.types.Substitutable;

/**
 * The base class of the various FeatherweightGJ expression types.
 */
public interface Term extends Node, Substitutable<Term> {

	/**
	 * Evaluate this term one step.
	 * @param eval the evaluator
	 * @return an updated term evaluated one step, or <code>null</code> if
	 * this term is already completely evaluated.
	 * @throws EvaluationException something went wrong during evaluation
	 */
	Term evaluate(Evaluator eval) throws EvaluationException;

	/**
	 * Get the value associated with this completely evaluated term.  Must only
	 * be called on completely evaluated terms.
	 * @param eval the evaluator
	 * @return the associated value
	 */
	Value value(Evaluator eval);
}
