package fgj.ast;

import fgj.sanity.MaybeInsane;

/**
 * Supertype of all AST nodes.
 */
public interface Node extends MaybeInsane {
	
	/**
	 * The line number where this AST node was read.
	 * @return the line number
	 */
	int lineNumber();
}
