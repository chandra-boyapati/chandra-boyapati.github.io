package fgj.ast;

import fgj.sanity.InsanityException;
import fgj.sanity.SanityChecker;
import fgj.types.Substitutable;
import fgj.types.Substitution;

/**
 * AST node representing a field or parameter declaration.
 */
public class Declaration extends AbstractNode implements Substitutable<Declaration> {

	/**
	 * The type of the variable being declared.
	 */
	public final Type type;
	
	/**
	 * The name of the variable.
	 */
	public final String name;
	
	/**
	 * Construct a new variable declaration.
	 * @param lineNumber position of this node
	 * @param type the type of the variable
	 * @param name the name of the variable
	 */
	public Declaration(int lineNumber, Type type, String name) {
		super(lineNumber);
		this.type = type;
		this.name = name;
	}

	/**
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object o) {
		Declaration d = (Declaration) o;
		return this.name.equals(d.name) && this.type.equals(d.type);
	}

	/**
	 * Sanity check a field or method argument declaration.
	 * @param sc the sanity checker
	 * @throws InsanityException the type is not sane
	 */
	public void sanityCheck(SanityChecker sc) throws InsanityException {
		type.sanityCheck(sc);
	}

	/**
	 * Perform a substitution on this declaration.
	 * @param subst the substitution to perform
	 * @return this declaration with the given type substitution applied
	 */
	public Declaration applySubstitution(Substitution<?> subst) {
		return new Declaration(lineNumber, type.applySubstitution(subst), name);
	}
}
