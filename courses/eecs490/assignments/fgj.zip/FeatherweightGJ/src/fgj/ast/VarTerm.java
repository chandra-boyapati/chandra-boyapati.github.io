package fgj.ast;

import fgj.eval.EvaluationException;
import fgj.eval.Evaluator;
import fgj.types.Substitution;

/**
 * AST node representing the reference of a variable.
 */
public class VarTerm extends AbstractTerm {

	/**
	 * The name of the variable being referenced.
	 */
	public final String name;
	
	/**
	 * Construct a new variable reference.
	 * @param lineNumber position of this node
	 * @param name the name of the variable being referenced
	 */
	public VarTerm(int lineNumber, String name) {
		super(lineNumber);
		this.name = name;
	}
	
	/**
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return name;
	}

	/**
	 * Apply a substitution to this variable term.
	 * @param subst the substitution to apply
	 * @return the term associated with <code>name</code>, or
	 * <code>this</code> if no substitution applied 
	 */
	public Term applySubstitution(Substitution<?> subst) {
		Term term = subst.lookupVariable(name);
		return term == null ? this : term;
	}

	/**
	 * Throw an exception--variable terms cannot be evaluated.
	 * @param eval the evaluator
	 * @return doesn't return
	 * @throws EvaluationException substitution did not replace this
	 * variable expression with some other term
	 */
	public Term evaluate(Evaluator eval) throws EvaluationException {
		throw new EvaluationException("unknown variable \"" + name + "\"");
	}
}
