package fgj.ast;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import fgj.sanity.InsanityException;
import fgj.sanity.SanityChecker;
import fgj.types.Substitutable;
import fgj.types.Substitution;

/**
 * AST node representing a method declaration.
 */
public class Method extends AbstractNode implements Substitutable<Method> {

	/**
	 * The list of {@linkplain TypeParam type parameters} which this
	 * method accepts.
	 */
	public final List<TypeParam> typeParams;
	
	/**
	 * The return type of the method.
	 */
	public final Type returnType;
	
	/**
	 * The name of the method.
	 */
	public final String name;
	
	/**
	 * The list of {@linkplain Declaration term parameters} which this
	 * method accepts.
	 */
	public final List<Declaration> termParams;
	
	/**
	 * The expression evaluated as the body of the method.
	 */
	public final Term body;
	
	/**
	 * The list of the types of <code>termParams</code>,
	 * provided as a convenience.
	 */
	public final List<Type> argTypes;
	
	/**
	 * The list of the names of <code>termParams</code>,
	 * provided as a convenience.
	 */
	public final List<String> argNames;
	
	/**
	 * Construct a new method declaration.
	 * @param lineNumber position of this node
	 * @param typeParams the type parameter list
	 * @param returnType the return type of the method
	 * @param name the name of the method
	 * @param termParams the {@linkplain Declaration term parameter} list
	 * @param body the body of the method
	 */
	public Method(int lineNumber, List<TypeParam> typeParams, Type returnType,
			String name, List<Declaration> termParams, Term body) {
		super(lineNumber);
		this.typeParams = Collections.unmodifiableList(typeParams);
		this.returnType = returnType;
		this.name = name;
		this.termParams = Collections.unmodifiableList(termParams);
		this.body = body;
		
		// Build the param names and types lists for later use
		LinkedList<Type> argTypes = new LinkedList<Type>();
		LinkedList<String> argNames = new LinkedList<String>();
		for (Declaration p : termParams) {
			argTypes.addLast(p.type);
			argNames.addLast(p.name);
		}
		this.argTypes = Collections.unmodifiableList(argTypes);
		this.argNames = Collections.unmodifiableList(argNames);
	}

	/**
	 * Sanity check a method declaration.
	 * @param sc the sanity checker
	 * @throws InsanityException one of the type parameters, one of
	 * the expression parameter declarations, the return type, or
	 * the method body were not sane 
	 */
	public void sanityCheck(SanityChecker sc) throws InsanityException {
		sc.checkList(typeParams);
		returnType.sanityCheck(sc);
		sc.checkList(termParams);
		body.sanityCheck(sc);
	}

	/**
	 * Apply a substitution to this method.
	 * @param subst the substitution to apply
	 * @return this method, with the type substitution applied to all the types
	 */
	public Method applySubstitution(Substitution<?> subst) {
		return new Method(lineNumber,
			subst.applyToList(typeParams),
			returnType.applySubstitution(subst),
			name,
			subst.applyToList(termParams),
			body.applySubstitution(subst));
	}	
}
