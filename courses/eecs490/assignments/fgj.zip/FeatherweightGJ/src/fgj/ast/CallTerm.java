package fgj.ast;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import fgj.eval.EvaluationException;
import fgj.eval.Evaluator;
import fgj.sanity.InsanityException;
import fgj.sanity.SanityChecker;
import fgj.types.MethodBody;
import fgj.types.Substitution;
import fgj.types.TermSubstitution;
import fgj.util.Pair;

/**
 * AST node representing a method invocation expression.
 */
public class CallTerm extends AbstractTerm {
	
	/**
	 * An expression which must evaluate to an object which
	 * accepts the <code>methodName</code> message.
	 */
	public final Term base;
	
	/**
	 * The method to invoke on <code>base</code>.
	 */
	public final String methodName;
	
	/**
	 * The list of {@link Type} arguments to apply to the
	 * parameterized method.
	 */
	public final List<Type> typeArgs;
	
	/**
	 * The list of {@link Term} expressions to apply as arguments
	 * to the method.
	 */
	public final List<Term> args;
	
	/**
	 * Construct a new method invocation term.
	 * @param lineNumber the position of this node
	 * @param base the base object
	 * @param methodName the message to send
	 * @param typeArgs the {@link Type} arguments to the method
	 * @param args the {@link Term} arguments to the method
	 */
	public CallTerm(int lineNumber, Term base, String methodName, List<Type> typeArgs,
			List<Term> args) {
		super(lineNumber);
		this.base = base;
		this.methodName = methodName;
		this.typeArgs = Collections.unmodifiableList(typeArgs);
		this.args = Collections.unmodifiableList(args);
	}
	
	/**
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return base + "." + methodName + strTypes(typeArgs) + strTerms(args);
	}

	/**
	 * Sanity check a method invocation expression.
	 * @param sc the sanity checker
	 * @throws InsanityException the base, one of the type arguments, or one
	 * of the expression arguments is not sane
	 */
	public void sanityCheck(SanityChecker sc) throws InsanityException {
		base.sanityCheck(sc);
		sc.checkList(typeArgs);
		sc.checkList(args);		
	}
	
	/**
	 * Apply a substitution to this term.
	 * @param subst the substitution to apply
	 * @return this term, with the substitution applied to the
	 * base, type arguments, and method arguments
	 */
	public CallTerm applySubstitution(Substitution<?> subst) {
		return new CallTerm(lineNumber, base.applySubstitution(subst),
				methodName, subst.applyToList(typeArgs), subst.applyToList(args));
	}

	/**
	 * Evaluate one step of this method invocation.
	 * @param eval the evaluator
	 * @return an updated version if the base expression or one of the
	 * expression arguments took a step, or else the invoked method body
	 * with all of its variable expressions substituted
	 * @throws EvaluationException the base or one of the arguments failed
	 * evaluation, or else no appropriate method could be found to invoke
	 */
	public Term evaluate(Evaluator eval) throws EvaluationException {
		
		// One step of the base
		Term newBase = base.evaluate(eval);
		if (newBase != null) {
			return new CallTerm(lineNumber, newBase, methodName, typeArgs, args);
		}
		
		// One step of the arguments
		List<Term> newArgs = eval.evaluateList(args);
		if (newArgs != null) {
			return new CallTerm(lineNumber, base, methodName, typeArgs, newArgs);
		}

		// Get the body of this method
		MethodBody body = eval.types.mbody(methodName, typeArgs, base.value(eval).type());
		if (body == null) {
			throw new EvaluationException("can't find an appropriate method \""
					+ methodName + "\"");
		}
		
		// Ensure the correct number of args
		if (body.paramNames.size() != args.size()) {
			throw new EvaluationException("incorrect number of arguments");
		}
	
		// Rule E-InvkNew: build a variable substitution and apply it
		Map<String, Term> newEnv = new HashMap<String, Term>();
		for (Pair<String, Term> p : Pair.zip(body.paramNames, args)) {
			newEnv.put(p.fst, p.snd);
		}
		newEnv.put("this", base);

		// Return the substituted body
		return body.term.applySubstitution(new TermSubstitution(newEnv));
	}
}
