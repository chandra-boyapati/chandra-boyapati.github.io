package fgj.ast;

import java.util.List;

import fgj.eval.EvaluationException;
import fgj.eval.Evaluator;
import fgj.eval.Value;
import fgj.sanity.InsanityException;
import fgj.sanity.SanityChecker;
import fgj.types.Substitution;
import fgj.util.Pair;

/**
 * AST node representing the accessing of a field of an object.
 */
public class FieldTerm extends AbstractTerm {

	/**
	 * An expression which must evaluate to an object which has
	 * a field named <code>fieldName</code>.
	 */
	public final Term base;
	
	/**
	 * The name of the field being accessed.
	 */
	public final String fieldName;
	
	/**
	 * Construct a new field access expression.
	 * @param lineNumber position of this node
	 * @param base the expression to dereference
	 * @param fieldName the name of the field to access
	 */
	public FieldTerm(int lineNumber, Term base, String fieldName) {
		super(lineNumber);
		this.base = base;
		this.fieldName = fieldName;
	}

	/**
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return base + "." + fieldName;
	}

	/**
	 * Sanity check a field access expression.
	 * @param sc the sanity checker
	 * @throws InsanityException the base expression is not sane
	 */
	public void sanityCheck(SanityChecker sc) throws InsanityException {
		base.sanityCheck(sc);
	}

	/**
	 * Apply a substitution to this term
	 * @param subst the substitution to apply
	 * @return this term, with the substitution applied to the base
	 */
	public FieldTerm applySubstitution(Substitution<?> subst) {
		return new FieldTerm(lineNumber, base.applySubstitution(subst), fieldName);
	}

	/**
	 * Evaluate one step of this field access expression.
	 * @param eval the evaluator
	 * @return an updated version if <code>base</code> was evaluated one step,
	 * or else the results of the projection
	 * @throws EvaluationException evaluation of <code>base</code> failed, or
	 * the projection failed
	 */
	public Term evaluate(Evaluator eval) throws EvaluationException {

		// Evaluate the base
		Term newBase = base.evaluate(eval);
		if (newBase != null) {
			return new FieldTerm(lineNumber, newBase, fieldName);
		}
		
		Value baseValue = base.value(eval);

		// Ensure the correct number of arguments to the constructor
		List<Declaration> fieldList = eval.types.fields(baseValue.type());
		List<Value> args = baseValue.arguments(eval);
		if (fieldList.size() != args.size()) {
			throw new EvaluationException("incorrect number of arguments to constructor");
		}
		
		// Rule E-ProjNew: project out the field we want
		for (Pair<Declaration, Value> p : Pair.zip(fieldList, args)) {
			if (p.fst.name.equals(fieldName)) return p.snd;
		}
		throw new EvaluationException("unknown field");		
	}
}
