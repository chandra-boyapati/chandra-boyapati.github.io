package fgj.ast;

import fgj.sanity.InsanityException;
import fgj.sanity.SanityChecker;
import fgj.types.Substitutable;
import fgj.types.Substitution;

/**
 * AST node representing a type parameter; that is, a type
 * variable name together with a non-variable bound.  Both classes
 * and methods possess lists of these.
 */
public class TypeParam extends AbstractNode implements Substitutable<TypeParam> {

	/**
	 * The name of the type parameter.
	 */
	public final String varName;
	
	/**
	 * The non-variable type bound.
	 */
	public final NonVariableType bound;
	
	/**
	 * Construct a new type parameter.
	 * @param lineNumber position of this node
	 * @param varName the type parameter name
	 * @param bound its non-variable bound
	 */
	public TypeParam(int lineNumber, String varName, NonVariableType bound) {
		super(lineNumber);
		this.varName = varName;
		this.bound = bound;
	}
	
	/**
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return varName + " extends " + bound;
	}

	/**
	 * Sanity check a type parameter.
	 * @param sc the sanity checker
	 * @throws InsanityException the bound was not sane
	 */
	public void sanityCheck(SanityChecker sc) throws InsanityException {
		bound.sanityCheck(sc);
	}

	/**
	 * Apply a type substitution to this type parameter.
	 * @param subst the substitution
	 * @return this type parameter, with the substitution applied to the bound 
	 */
	public TypeParam applySubstitution(Substitution<?> subst) {
		return new TypeParam(lineNumber, varName, bound.applySubstitution(subst));
	}
}
