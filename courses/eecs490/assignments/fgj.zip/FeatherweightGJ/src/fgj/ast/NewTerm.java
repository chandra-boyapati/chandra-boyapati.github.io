package fgj.ast;

import java.util.Collections;
import java.util.List;

import fgj.eval.EvaluationException;
import fgj.eval.Evaluator;
import fgj.eval.Value;
import fgj.sanity.InsanityException;
import fgj.sanity.SanityChecker;
import fgj.types.Substitution;

/**
 * AST node representing a constructor invocation through
 * <code>new</code>.
 */
public class NewTerm extends AbstractTerm implements Value {

	/**
	 * The type of the object being constructed.
	 */
	public final NonVariableType type;
	
	/**
	 * The list of {@link Term} arguments to the constructor.
	 */
	public final List<Term> args;
	
	/**
	 * Construct a new constructor invocation expression.
	 * @param lineNumber position of this node
	 * @param type the type to construct
	 * @param args the {@link Term} arguments to the constructor
	 */
	public NewTerm(int lineNumber, NonVariableType type, List<Term> args) {
		super(lineNumber);
		this.type = type;
		this.args = Collections.unmodifiableList(args);
	}
	
	/**
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return "new " + type + strTerms(args);
	}

	/**
	 * Check the sanity of a new expression.
	 * @param sc the sanity checker
	 * @throws InsanityException either the type or one of the arguments
	 * is not sane
	 */
	public void sanityCheck(SanityChecker sc) throws InsanityException {
		type.sanityCheck(sc);
		sc.checkList(args);
	}
	
	/**
	 * Apply a substitution to this term.
	 * @param subst the substitution to apply
	 * @return this term, with substitution applied to everything
	 */
	public NewTerm applySubstitution(Substitution<?> subst) {
		return new NewTerm(lineNumber, type.applySubstitution(subst), subst.applyToList(args));
	}

	/**
	 * Evaluate one step of this new expression.
	 * @param eval the evaluator
	 * @return an updated version if one of our arguments was evaluated,
	 * or else <code>null</code> if we are completely evaluated
	 * @throws EvaluationException evaluation of one of the constructor
	 * arguments failed
	 */
	public Term evaluate(Evaluator eval) throws EvaluationException {
		
		// One step on the arguments
		List<Term> newArgs = eval.evaluateList(args);
		if (newArgs != null) {
			return new NewTerm(lineNumber, type, newArgs);
		}
		
		// We are values
		return null;
	}

	/**
	 * Return <code>this</code>, because new terms are the values in FGJ.
	 * @param eval the evaluator
	 * @return <code>this</code>
	 */
	public Value value(Evaluator eval) {
		return this;
	}

	/**
	 * @see fgj.eval.Value#type()
	 */
	public NonVariableType type() {
		return type;
	}

	/**
	 * @see fgj.eval.Value#arguments(Evaluator)
	 */
	public List<Value> arguments(Evaluator eval) {
		return eval.toValues(args);
	}
}
