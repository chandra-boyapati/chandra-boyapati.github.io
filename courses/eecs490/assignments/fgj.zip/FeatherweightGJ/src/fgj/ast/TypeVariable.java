package fgj.ast;

import java.util.Collections;
import java.util.Set;

import fgj.typecheck.TypeEnvironment;
import fgj.typecheck.TypeException;
import fgj.types.Substitution;

/**
 * AST node representing the use of a type variable as a type.
 * The use of a type variable always occurs in the scope of a class
 * or method which declared it in its {@link TypeParam} list.
 */
public class TypeVariable extends AbstractNode implements Type {

	/**
	 * The name of the type variable.
	 */
	public final String name;
	
	/**
	 * Construct a new type variable.
	 * @param lineNumber position of this node
	 * @param name the name of the type variable
	 */
	public TypeVariable(int lineNumber, String name) {
		super(lineNumber);
		this.name = name;
	}

	/**
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object o) {
		if (!(o instanceof TypeVariable)) return false;
		return ((TypeVariable) o).name.equals(this.name);
	}
	
	/**
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return name;
	}

	/**
	 * Apply a substitution to this type variable.
	 * @param subst the substitution to apply
	 * @return the substitution of this type variable, or <code>this</code>
	 * if no substitution applies
	 */
	public Type applySubstitution(Substitution<?> subst) {
		Type ty = subst.lookupTypeVariable(name);
		return (ty == null) ? this : ty;
	}

	/**
	 * Ensure that this type variable is defined in the given type environment.
	 * @param typeEnv the type environment
	 * @throws TypeException the type variable is not defined in the given environment
	 */
	public void checkWellFormed(TypeEnvironment typeEnv) throws TypeException {
		if (!typeEnv.isDefined(name)) {
			throw new TypeException("type variable \"" + name
					+ "\" is not well formed");
		}
	}

	/**
	 * Return the bound of this type variable.
	 * @param typeEnv the type environment
	 * @return the nonvariable bound of this type variable
	 */
	public NonVariableType bound(TypeEnvironment typeEnv) {
		NonVariableType bound = typeEnv.getBound(name);
		if (bound == null) {
			throw new Error("type variable is not defined in this scope");
		}
		return bound;
	}

	/**
	 * @see fgj.ast.Type#freeVariables()
	 */
	public Set<String> freeVariables() {
		return Collections.singleton(name);
	}
}
