package fgj.ast;

import java.util.Iterator;
import java.util.List;

import fgj.sanity.InsanityException;
import fgj.sanity.SanityChecker;

/**
 * Superclass of all AST nodes which remember the line they were parsed from.
 */
public abstract class AbstractNode implements Node {

	/**
	 * The line number of this node.
	 */
	protected final int lineNumber;
	
	/**
	 * Construct a new node with the given line number.
	 * @param lineNumber the line number
	 */
	protected AbstractNode(int lineNumber) {
		this.lineNumber = lineNumber;
	}
	
	/**
	 * Return the line number of this node.
	 * @return the line number
	 */
	public final int lineNumber() {
		return lineNumber;
	}

	/**
	 * Default implementation of sanity check: do nothing.
	 * @param sc the sanity checker
	 * @throws InsanityException not thrown
	 */
	public void sanityCheck(SanityChecker sc) throws InsanityException {
		// Do nothing
	}
	
	/**
	 * Utility to convert a list to a string.
	 * @param list the list to convert
	 * @return the string representation
	 */
	public static String str(List<?> list) {
		if (list.isEmpty()) return "";
		StringBuffer sb = new StringBuffer();
		sb.append(list.get(0));
		for (Iterator<?> i = list.listIterator(1); i.hasNext(); ) {
			sb.append(',').append(i.next());
		}
		return sb.toString();
	}
	
	/**
	 * Utility to convert a list of terms to a string.
	 * @param terms the list to convert
	 * @return the string representation
	 */
	public static String strTerms(List<Term> terms) {
		return "(" + str(terms) + ")";
	}
	
	/**
	 * Utility to convert a list of types to a string.
	 * @param types the list to convert
	 * @return the string representation
	 */
	public static String strTypes(List<Type> types) {
		return types.isEmpty() ? "" : "<" + str(types) + ">";
	}
}
