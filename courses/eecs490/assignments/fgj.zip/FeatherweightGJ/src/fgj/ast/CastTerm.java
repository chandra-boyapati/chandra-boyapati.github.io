package fgj.ast;

import fgj.eval.EvaluationException;
import fgj.eval.Evaluator;
import fgj.eval.Value;
import fgj.sanity.InsanityException;
import fgj.sanity.SanityChecker;
import fgj.typecheck.TypeEnvironment;
import fgj.types.Substitution;

/**
 * AST node representing casting of an object from one type
 * to another.
 */
public class CastTerm extends AbstractTerm {
	
	/**
	 * The target type, or the type to which to cast.
	 */
	public final NonVariableType type;
	
	/**
	 * The expression to cast to <code>type</code>.
	 */
	public final Term term;
	
	/**
	 * Construct a new cast expression.
	 * @param lineNumber position of this node
	 * @param type the type to cast to
	 * @param term the expression to cast
	 */
	public CastTerm(int lineNumber, NonVariableType type, Term term) {
		super(lineNumber);
		this.type = type;
		this.term = term;
	}

	/**
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return "((" + type + ")" + term + ")";
	}

	/**
	 * Sanity check a cast expression.
	 * @param sc the sanity checker
	 * @throws InsanityException either the type or the term is not sane
	 */
	public void sanityCheck(SanityChecker sc) throws InsanityException {
		type.sanityCheck(sc);
		term.sanityCheck(sc);
	}

	/**
	 * Apply a substitution to this term.
	 * @param subst the substitution to apply
	 * @return the substituted type and argument
	 */
	public CastTerm applySubstitution(Substitution<?> subst) {
		return new CastTerm(lineNumber, type.applySubstitution(subst),
				term.applySubstitution(subst));
	}

	/**
	 * Evaluate one step of a type cast.
	 * @param eval the evaluator
	 * @return an updated version if our subterm was evaluated, or else
	 * the subterm if the cast succeeds
	 * @throws EvaluationException evaluation of the base term failed, or
	 * else the cast was invalid
	 */
	public Term evaluate(Evaluator eval) throws EvaluationException {
		
		// Evaluate our subterm one step
		Term newTerm = term.evaluate(eval);
		if (newTerm != null) {
			return new CastTerm(lineNumber, type, newTerm);
		}
		Value value = term.value(eval);
		
		// Rule E-CastNew: just return the value if the cast is okay
		if (new TypeEnvironment(eval.types).subtype(value.type(), type)) {
			return value;
		}
		else {
			throw new EvaluationException("invalid cast");
		}	
	}
}
