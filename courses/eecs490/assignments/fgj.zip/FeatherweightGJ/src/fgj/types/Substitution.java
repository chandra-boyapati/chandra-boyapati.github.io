package fgj.types;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import fgj.ast.Term;
import fgj.ast.Type;

/**
 * Utility class which performs type or value substitutions.
 * @param <X> the type of objects substituting strings
 */
public abstract class Substitution<X> {
	
	/**
	 * Mapping of type variable names to types.
	 */
	private final Map<String, X> map;
	
	/**
	 * Construct a substitution, mapping names to arguments.
	 * @param map the map from names to their substitutions
	 */
	protected Substitution(Map<String, X> map) {
		this.map = Collections.unmodifiableMap(map);
	}

	/**
	 * Look up a name in the substitution.
	 * @param name the name to lookup
	 * @return the object to substitute, or <code>null</code> if no
	 * substitution applies
	 */
	protected X lookup(String name) {
		return map.get(name);
	}

	/**
	 * Lookup a type variable in this substitution.
	 * @param name the name of the type variable to lookup
	 * @return its replacement type, or <code>null</code>
	 */
	public Type lookupTypeVariable(String name) {
		return null;
	}

	/**
	 * Lookup a (value) variable in this substitution.
	 * @param name the name of the variable to lookup
	 * @return its replacement term, or <code>null</code>
	 */
	public Term lookupVariable(String name) {
		return null;
	}

	/**
	 * Apply a substitution to a list of substitutables.
	 * @param <Y> the type being substituted to
	 * @param list the list of substitutables
	 * @return an immutable list of the objects with this substitution applied
	 */
	public <Y extends Substitutable<Y>> List<Y> applyToList(List<Y> list) {
		List<Y> newList = new LinkedList<Y>();
		for (Substitutable<Y> y : list) {
			newList.add(y.applySubstitution(this));
		}
		return Collections.unmodifiableList(newList);
	}
}
