package fgj.types;

/**
 * Implemented by classes to which a substitution can be applied.
 * In Featherweight GJ, type substitutions apply to types and terms.
 * @param <T> the return type of the applySubstitution method
 */
public interface Substitutable<T> {
	
	/**
	 * Apply a substitution to an object.
	 * @param subst the substitution to apply
	 * @return an object upon which a substitution has been applied
	 */
	T applySubstitution(Substitution<?> subst);
}
