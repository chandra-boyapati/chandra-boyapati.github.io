package fgj.types;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import fgj.ast.Type;
import fgj.ast.TypeParam;
import fgj.util.Pair;

/**
 * Substitutions from type variables to types.
 */
public class TypeSubstitution extends Substitution<Type> {

	/**
	 * Construct a new type substitution.
	 * @param typeArgs the arguments supplied to the type parameters
	 * @param typeParams the list of parameters (names and bounds)
	 */
	public TypeSubstitution(List<Type> typeArgs, List<TypeParam> typeParams) {
		super(buildMap(typeArgs, typeParams));
	}
	
	/**
	 * Build a mapping of type variable names to types.
	 * @param typeArgs the arguments supplied to the type parameters
	 * @param typeParams the list of parameters (names and bounds)
	 * @return the mapping from variable names to types
	 */
	private static Map<String, Type> buildMap(List<Type> typeArgs, List<TypeParam> typeParams) {
		// build the map
		Map<String, Type> map = new HashMap<String, Type>();
		for (Pair<TypeParam,Type> p : Pair.zip(typeParams, typeArgs)) {
			map.put(p.fst.varName, p.snd);
		}
		
		// make sure it doesn't change
		return Collections.unmodifiableMap(map);
	}
	
	/**
	 * @see fgj.types.Substitution#lookupTypeVariable(String)
	 */
	public Type lookupTypeVariable(String name) {
		return lookup(name);
	}
}
