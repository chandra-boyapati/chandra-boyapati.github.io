package fgj.types;

import java.util.Map;

import fgj.ast.Term;

/**
 * Substitutions from variable names to terms.
 */
public class TermSubstitution extends Substitution<Term> {

	/**
	 * Construct a new term substitution.
	 * @param map mapping of variable names to terms
	 */
	public TermSubstitution(Map<String, Term> map) {
		super(map);
	}

	/**
	 * @see fgj.types.Substitution#lookupVariable(String)
	 */
	public Term lookupVariable(String name) {
		return lookup(name);
	}
}
