package fgj.types;

import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import fgj.ast.*;
import fgj.sanity.InsanityException;
import fgj.sanity.SanityChecker;

/**
 * The class table (the <i>CT</i> in the FeatherweightGJ paper)
 * used as a database of class information throughout typechecking
 * and evaluation.  The class table is used by both the type checker
 * and the evaluator, and thus must be built first.  During its
 * construction, we detect six different errors:
 * 
 * <ol>
 * <li>declaring a class which has already been declared</li>
 * <li>declaring a field which has already been declared
 * in the given class or its superclass (transitively)</li>
 * <li>declaring a method which has already been declared
 * in the given class</li>
 * <li>declaring a type variable which has already been declared
 * in the given class or method</li>
 * <li>extending an unknown class</li>
 * <li>introducing a cycle in the subclass relation</li>
 * </ol>
 *
 * This class also supplies definitions of the <code>mbody</code>,
 * <code>mtype</code>, and <code>fields</code>
 * functions defined in the <i>auxiliary definitions</i> table in
 * the FeatherweightGJ paper.
 */
public class ClassTable {
	
	/**
	 * A mapping from class names (String) to their
	 * corresponding {@link ClassDecl} structures.
	 */
	private final Map<String, ClassDecl> classMap;

	/**
	 * Build a class table from a FGJ program.  This object can
	 * then be used in typechecking and evaluation.
	 * @param program An FGJ program
	 * @throws InsanityException a class, type variable,
	 * field, or method is multiply defined, a class extends an
	 * unknown class, or a cycle in the subclassing relation is introduced
	 */
	public ClassTable(Program program) throws InsanityException {
		Map<String, ClassDecl> classMap = new HashMap<String, ClassDecl>();
		
		// Add the classes, and check for duplicates
		for (ClassDecl cd : program.classDecls) {
			if (classMap.containsKey(cd.name)) {
				throw new InsanityException(cd, "multiply defined class \"" + cd.name + "\"");
			}
			if (cd.name.equals("Object")) {
				throw new InsanityException(cd, "cannot define Object");
			}
			classMap.put(cd.name, cd);
		}
		this.classMap = Collections.unmodifiableMap(classMap);
		
		// Check for cycles
		for (ClassDecl cd : program.classDecls) {
			if (subClass(cd.superType.className, cd.name)) {
				throw new InsanityException(cd, "cycle in the subclass relation");
			}
		}
		
		// Sanity check everything now so class table errors needn't be thrown later
		SanityChecker sc = new SanityChecker(this.classMap);
		for (ClassDecl cd : program.classDecls) {
			cd.sanityCheck(sc);
		}
		program.term.sanityCheck(sc);
	}
	
	/**
	 * Find the class declaration corresponding to the given class name.
	 * @param className the name of the class to lookup
	 * @return its class declaration AST node
	 */
	private ClassDecl lookup(String className) {
		ClassDecl cd = classMap.get(className);
		if (cd == null) {
			throw new Error("something is horribly wrong with the class table");
		}
		return cd;
	}
	
	/**
	 * Return the list of type parameters of the given class.
	 * @param className the class to lookup
	 * @return its type parameters
	 */
	public List<TypeParam> typeParams(String className) {
		return lookup(className).typeParams;
	}
	
	/**
	 * Return the super type of a given class.
	 * @param className the class to lookup
	 * @return its super type
	 */
	public NonVariableType superType(String className) {
		return lookup(className).superType;
	}
		
	/**
	 * Return the list of fields of the given type. 
	 * @param type the type to lookup
	 * @return a list of {@link Declaration} structures corresponding
	 * to the fields of that type
	 */
	public List<Declaration> fields(NonVariableType type) {
		
		// Object has no fields
		if (type.isObject()) return Collections.emptyList();
		
		// Get our declaration
		ClassDecl cd = lookup(type.className);
		List<Declaration> fields = new LinkedList<Declaration>();
		
		// Create a substitution with our arguments
		TypeSubstitution subst = new TypeSubstitution(type.typeArgs, cd.typeParams);
		
		// Fetch the fields of our super type
		fields.addAll(fields(cd.superType.applySubstitution(subst)));
		
		// Add our fields, substituting on the way
		for (Declaration f : cd.fields) {
			fields.add(f.applySubstitution(subst));
		}
		
		return fields;
	}
	
	/**
	 * Return the MethodType structure corresponding to the requested
	 * method.
	 * @param methodName the name of the method to lookup
	 * @param type the type to begin searching in
	 * @return the MethodType structure, or <code>null</code> if none was found
	 */
	public MethodType mtype(String methodName, NonVariableType type) {
		
		// Object has no methods
		if (type.isObject()) return null;
		ClassDecl cd = lookup(type.className);
		
		// Construct a substitution with the class parameters
		TypeSubstitution subst = new TypeSubstitution(type.typeArgs, cd.typeParams);
		
		// Look for it in this class
		for (Method method : cd.methods) {
			if (method.name.equals(methodName)) {
				return new MethodType(method.applySubstitution(subst));
			}
		}
		
		// We didn't find it; try the substituted parent
		return mtype(methodName, cd.superType.applySubstitution(subst));		
	}
	
	/**
	 * Return the MethodBody structure corresponding to the requested
	 * method.
	 * @param methodName the name of the method to lookup
	 * @param typeArgs the type arguments passed to the method call
	 * @param type the type to begin searching in
	 * @return the MethodBody structure, or <code>null</code> if none was found
	 */
	public MethodBody mbody(String methodName, List<Type> typeArgs,	NonVariableType type) {
		
		// Object has no methods
		if (type.isObject()) return null;
		ClassDecl cd = lookup(type.className);
		
		// Construct a substitution with the class parameters
		TypeSubstitution subst = new TypeSubstitution(type.typeArgs, cd.typeParams);
		
		// Look for it in this class
		for (Method method : cd.methods) {
			if (method.name.equals(methodName)) {
				
				// We found it; add the method substitutions and go
				TypeSubstitution methSubst =
					new TypeSubstitution(typeArgs, method.typeParams);
				return new MethodBody(method.argNames,
						method.body
							.applySubstitution(subst)
							.applySubstitution(methSubst));
			}
		}
		
		// We didn't find it; try the substituted parent
		return mbody(methodName, typeArgs, cd.superType.applySubstitution(subst));
	}

	/**
	 * Implement the subclass (<i>not</i> the subtype) relation
	 * @param subName a class name
	 * @param superName another class name
	 * @return <code>true</code> if subName is a subclass of superName
	 */
	public boolean subClass(String subName, String superName) {
		
		// Every class is a subclass of object
		if (superName.equals("Object")) return true;
		
		// Keep looking till we hit object
		while (!subName.equals("Object")) {
			if (subName.equals(superName)) return true;
			subName = superType(subName).className;
		}
		
		// We hit object
		return false;
	}
}
