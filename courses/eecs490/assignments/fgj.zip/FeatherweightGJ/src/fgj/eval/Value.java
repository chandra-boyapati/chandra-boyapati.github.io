package fgj.eval;

import java.util.List;

import fgj.ast.NonVariableType;
import fgj.ast.Term;

/**
 * A value in FeatherweightGJ is recursively defined as a new-expression with
 * all its arguments completely evaluated as values.
 */
public interface Value extends Term {

	/**
	 * The type of this value.
	 * @return the type
	 */
	NonVariableType type();
	
	/**
	 * The constructor arguments, or fields, of this value.
	 * @param eval the evaluator
	 * @return the list of argument values
	 */
	List<Value> arguments(Evaluator eval);
}
