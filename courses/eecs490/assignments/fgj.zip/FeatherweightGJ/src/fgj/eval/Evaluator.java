package fgj.eval;

import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import fgj.ast.Term;
import fgj.types.ClassTable;

/**
 * The core of the FeatherweightGJ evaluation engine.  Given a class
 * table, an evaluator maps abstract {@link Term} objects into
 * concrete {@link Value} objects, which may then be printed nicely.
 */
public class Evaluator {
	
	/**
	 * The class table.
	 */
	public final ClassTable types;

	/**
	 * Construct an evaluator with the given class table.
	 * @param types the class table
	 */
	public Evaluator(ClassTable types) {
		this.types = types;
	}

	/**
	 * Evaluate one step of a list of terms.
	 * @param terms the terms to evaluate
	 * @return a new list of terms, with one step done in one of the terms, or
	 * <code>null</code> if all the terms were already evaluated 
	 * @throws EvaluationException the evaluator got stuck during evaluation of
	 * one of the terms
	 */	
	public List<Term> evaluateList(List<Term> terms) throws EvaluationException {

		// We'll be building a new list of terms
		List<Term> newTerms = new LinkedList<Term>();
		Iterator<Term> i = terms.iterator();
		boolean takenStep = false;
		
		// Keep adding until we see one that hasn't been evaluated yet
		while (i.hasNext()) {
			Term term = i.next();
			Term newTerm = term.evaluate(this);
			if (newTerm == null) {
				newTerms.add(term);
			}
			else {
				takenStep = true;
				newTerms.add(newTerm);
				break;
			}
		}
		
		// Now just add the rest without evaluation
		while (i.hasNext()) {
			newTerms.add(i.next());
		}
		
		// Return a new list if anything changed
		return takenStep ? Collections.unmodifiableList(newTerms) : null;
	}

	/**
	 * Convert a list of completely evaluated terms to a list of values.
	 * @param terms the list of evaluated terms
	 * @return the list of values
	 */
	public List<Value> toValues(List<Term> terms) {
		List<Value> values = new LinkedList<Value>();
		for (Term term : terms) {
			values.add(term.value(this));
		}
		return Collections.unmodifiableList(values);
	}
}
