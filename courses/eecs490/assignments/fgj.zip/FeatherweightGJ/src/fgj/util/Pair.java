package fgj.util;

import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 * Pairs of objects.
 * @param <X> the type of the first element of the pair
 * @param <Y> the type of the second element of the pair
 */
public class Pair<X,Y> {

	/**
	 * The first element.
	 */
	public final X fst;
	
	/**
	 * The second element.
	 */
	public final Y snd;
	
	/**
	 * Construct a new pair.
	 * @param fst the first element
	 * @param snd the second element
	 */
	public Pair(X fst, Y snd) {
		this.fst = fst;
		this.snd = snd;
	}
	
	/**
	 * Build a list of pairs from a pair of lists with the same length.
	 * @param <X> the type of the first element
	 * @param <Y> the type of the second element
	 * @param xs the list of first elements
	 * @param ys the list of second elements
	 * @return the immutable list of pairs
	 */
	public static <X,Y> List<Pair<X,Y>> zip(List<X> xs, List<Y> ys) {
		
		// the lists should have the same length always
		if (xs.size() != ys.size()) {
			throw new Error("cannot zip lists of unequal size!");
		}
		
		// build the pairs
		Iterator<X> x = xs.iterator();
		Iterator<Y> y = ys.iterator();
		List<Pair<X,Y>> theList = new LinkedList<Pair<X,Y>>();		
		while (x.hasNext() && y.hasNext()) {
			theList.add(new Pair<X,Y>(x.next(), y.next()));
		}
		
		// return an immutable view
		return Collections.unmodifiableList(theList);
	}
}
