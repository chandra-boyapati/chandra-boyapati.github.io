package fgj.parse;

/**
 * The return type of {@link Lexer#nextToken()}.  Every token produced
 * by the lexer has an integer identifier, along with a string value
 * if it is a FeatherweightGJ identifier.
 */
public class Token {

	/**
	 * The identifying number of this type of token.
	 */
	public final Type id;
	
	/**
	 * The value of this token; only valid when
	 * <code>id == IDENTIFIER</code>.
	 */
	public final String value;
	
	/**
	 * Construct a new non-identifier token.
	 * @param id the number of this token
	 */
	public Token(Type id) {
		this.id = id;
		this.value = null;
	}
	
	/**
	 * Construct an identifier token.
	 * @param value the identifier to associate with this token
	 */
	public Token(String value) {
		this.id = Type.IDENTIFIER;
		this.value = value;
	}
	
	/**
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		if (this.id == Type.IDENTIFIER) {
			return "\"" + this.value + "\"";
		}
		else {
			return this.id.toString();
		}
	}
	
	/**
	 * The tokens.
	 */
	public static enum Type {
		EOF,
		CLASS,
		IDENTIFIER,
		EXTENDS,
		LBRACE,
		RBRACE,
		LPAREN,
		RPAREN,
		SUPER,
		COMMA,
		SEMI,
		THIS,
		DOT,
		EQUAL,
		RETURN,
		NEW,
		LT,
		GT
	}
}
